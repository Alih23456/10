import { useEffect, useState } from 'react';
import ProductCard from '../components/ProductCard.jsx';

export default function Catalog() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetch('/api/products')
      .then(response => {
        if (!response.ok) throw new Error('Ошибка сервера');
        return response.json();
      })
      .then(data => setProducts(data))
      .catch(() => setError('Не удалось загрузить товары'))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <main><p>Загрузка товаров...</p></main>;
  if (error) return <main><p role="alert">{error}</p></main>;
  if (!products.length) return <main><h1>Каталог</h1><p>Товаров пока нет</p></main>;
  return <main><h1>Каталог товаров</h1><div className="products">
    {products.map(product => <ProductCard key={product.id} product={product} />)}
  </div></main>;
}
