import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Catalog from './Catalog.jsx';

const products = [
  { id: 1, name: 'Мёд гречишный', price: 3500, category: 'Мёд', stock: 4 },
  { id: 2, name: 'Пшеница 3 класса', price: 120, category: 'Зерно', stock: 10 }
];

function mockFetch(body, status = 200) {
  return vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify(body), {
    status, headers: { 'Content-Type': 'application/json' }
  }));
}
function renderCatalog() {
  return render(<MemoryRouter><Catalog /></MemoryRouter>);
}

describe('Catalog', () => {
  test('сначала показывает загрузку, потом товары', async () => {
    mockFetch(products);
    renderCatalog();
    expect(screen.getByText(/загрузка/i)).toBeInTheDocument();
    expect(await screen.findByText('Мёд гречишный')).toBeInTheDocument();
    expect(screen.getByText('Пшеница 3 класса')).toBeInTheDocument();
    expect(screen.queryByText(/загрузка/i)).not.toBeInTheDocument();
  });
  test('делает запрос к /api/products', async () => {
    const spy = mockFetch(products);
    renderCatalog();
    await screen.findByText('Мёд гречишный');
    expect(spy).toHaveBeenCalledTimes(1);
    expect(String(spy.mock.calls[0][0])).toMatch(/\/api\/products/);
  });
  test('показывает ошибку при ответе сервера 500', async () => {
    mockFetch({ error: 'server error' }, 500);
    renderCatalog();
    expect(await screen.findByRole('alert')).toHaveTextContent(/не удалось/i);
  });
  test('показывает пустой каталог', async () => {
    mockFetch([]);
    renderCatalog();
    expect(await screen.findByText(/товаров пока нет/i)).toBeInTheDocument();
  });
  test('показывает ошибку, если сеть недоступна', async () => {
    vi.spyOn(globalThis, 'fetch').mockRejectedValue(new TypeError('Failed to fetch'));
    renderCatalog();
    expect(await screen.findByRole('alert')).toHaveTextContent(/не удалось/i);
  });
});
