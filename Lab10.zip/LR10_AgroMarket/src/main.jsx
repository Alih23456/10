import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter, Link, Route, Routes } from 'react-router-dom';
import Catalog from './pages/Catalog.jsx';
import LoginForm from './components/LoginForm.jsx';
import './style.css';

function App() {
  return <BrowserRouter>
    <header><Link to="/">АгроМаркет</Link><nav><Link to="/">Каталог</Link> <Link to="/login">Войти</Link></nav></header>
    <Routes>
      <Route path="/" element={<Catalog />} />
      <Route path="/login" element={<main><h1>Вход</h1><LoginForm onSubmit={(data) => console.log(data)} /></main>} />
      <Route path="*" element={<main><h1>Страница не найдена</h1></main>} />
    </Routes>
  </BrowserRouter>;
}

createRoot(document.getElementById('root')).render(<App />);
