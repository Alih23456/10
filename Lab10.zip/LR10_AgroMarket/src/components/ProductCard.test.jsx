import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import ProductCard from './ProductCard.jsx';

const product = { id: 1, name: 'Мёд гречишный', price: 3500, category: 'Мёд', stock: 5 };

describe('ProductCard', () => {
  test('показывает название товара', () => {
    render(<ProductCard product={product} />);
    expect(screen.getByRole('heading', { name: 'Мёд гречишный' })).toBeInTheDocument();
  });
  test('показывает цену', () => {
    render(<ProductCard product={product} />);
    expect(screen.getByText(/3\s?500/)).toBeInTheDocument();
  });
  test('показывает категорию', () => {
    render(<ProductCard product={product} />);
    expect(screen.getByText('Категория: Мёд')).toBeInTheDocument();
  });
  test('по нажатию вызывает onAdd с товаром', async () => {
    const user = userEvent.setup();
    const onAdd = vi.fn();
    render(<ProductCard product={product} onAdd={onAdd} />);
    await user.click(screen.getByRole('button', { name: /в заявку/i }));
    expect(onAdd).toHaveBeenCalledTimes(1);
    expect(onAdd).toHaveBeenCalledWith(product);
  });
  test('для товара без остатка кнопка отключена', () => {
    render(<ProductCard product={{ ...product, stock: 0 }} />);
    expect(screen.getByRole('button', { name: /в заявку/i })).toBeDisabled();
    expect(screen.getByText(/нет в наличии/i)).toBeInTheDocument();
  });
});
