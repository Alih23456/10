export default function ProductCard({ product, onAdd = () => {} }) {
  const unavailable = product.stock === 0;
  return <article className="card" data-testid="product-card">
    <h2>{product.name}</h2>
    <p>Категория: {product.category}</p>
    <p>{product.price.toLocaleString('ru-RU')} ₸</p>
    {unavailable && <p>Нет в наличии</p>}
    <button disabled={unavailable} onClick={() => onAdd(product)}>В заявку</button>
  </article>;
}
