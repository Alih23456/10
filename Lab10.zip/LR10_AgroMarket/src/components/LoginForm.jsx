import { useState } from 'react';

export default function LoginForm({ onSubmit = () => {} }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function submit(event) {
    event.preventDefault();
    if (!email.trim() || !password) {
      setError('Заполните все поля');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      setError('Введите корректный e-mail');
      return;
    }
    setError('');
    onSubmit({ email, password });
  }

  return <form onSubmit={submit}>
    <label htmlFor="email">E-mail</label>
    <input id="email" type="email" value={email} onChange={e => setEmail(e.target.value)} />
    <label htmlFor="password">Пароль</label>
    <input id="password" type="password" value={password} onChange={e => setPassword(e.target.value)} />
    {error && <p className="error" role="alert">{error}</p>}
    <button type="submit">Войти</button>
  </form>;
}
