import { test, expect } from '@playwright/test';

test('каталог открывается и показывает товары или пустое состояние', async ({ page }) => {
  await page.goto('/');
  await expect(page).toHaveTitle(/АгроМаркет/i);
  await expect(page.getByRole('heading', { name: /каталог/i })).toBeVisible();
  await expect(page.getByText(/загрузка|товаров пока нет|мёд гречишный/i)).toBeVisible();
});

test('прямая ссылка на страницу входа не возвращает 404', async ({ page }) => {
  const response = await page.goto('/login');
  expect(response.status()).toBe(200);
  await expect(page.getByRole('heading', { name: 'Вход' })).toBeVisible();
});

test('форма входа проверяет пустые поля', async ({ page }) => {
  await page.goto('/login');
  await page.getByRole('button', { name: /войти/i }).click();
  await expect(page.getByRole('alert')).toHaveText(/заполните/i);
});
